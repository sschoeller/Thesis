#!/usr/bin/env python3
import random
S = ""
for i in range(0,51): # 51 letters long
	# generate psuedorandom number
	randomNum = random.randint(0,4)
	char = ''
	# set character
	if randomNum == 0:
		# generate another pseudorandom number to determine which small case letter
		randNum = random.randint(0,3)
		if randomNum == 0:
			char = 'a'
			S += char
		elif randomNum == 1:
			char ='t'
			S += char
		elif randomNum == 2:
			char == 'c'
			S += char
		elif randomNum == 3:
			char == 'g'
			S += char
	elif randomNum == 1:
		char = 'A'
		S += char
	elif randomNum == 2:
		char = 'T'
		S += char
	elif randomNum == 3:
		char = 'C'
		S += char
	elif randomNum == 4:
		char = 'G'
		S += char
		
print(S) # use CLI redirect
